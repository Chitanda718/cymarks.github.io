 商品分类筛选功能
document.addEventListener('DOMContentLoaded', function() {
    const categoryButtons = document.querySelectorAll('.category-btn');
    const productCards = document.querySelectorAll('.product-card');
    
    if(categoryButtons.length  0) {
        categoryButtons.forEach(button = {
            button.addEventListener('click', function() {
                 移除所有按钮的active类
                categoryButtons.forEach(btn = btn.classList.remove('active'));
                 给当前点击的按钮添加active类
                this.classList.add('active');
                
                const category = this.getAttribute('data-category');
                
                 筛选商品
                productCards.forEach(card = {
                    if(category === 'all'  card.getAttribute('data-category') === category) {
                        card.style.display = 'block';
                    } else {
                        card.style.display = 'none';
                    }
                });
            });
        });
    }
    
     简单的表单验证
    const contactForm = document.querySelector('.contact-form form');
    if(contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const name = document.getElementById('name').value;
            const email = document.getElementById('email').value;
            const message = document.getElementById('message').value;
            
            if(name && email && message) {
                alert('感谢您的留言！我们会尽快与您联系。');
                this.reset();
            } else {
                alert('请填写所有必填字段！');
            }
        });
    }
});